public interface SoundMaker {
    void makeSound(); //On déclare une méthode non implémentée
}
